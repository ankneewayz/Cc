<?php
// =======================================================
// BOT CONFIGURATION - FILL WITH YOUR DATA
// =======================================================

// Bot token obtained from @BotFather
$botToken = "8844529806:AAHBbXR6kbkxNMpqXHXUy1xIirRcdwy9PIk";  // e.g., "5456276655:AAFt3u9hGVZxA72kBJrTc9W-Bmp7CWjLJBA"

// Your Telegram user ID (you = admin/owner)
$Mi_Id =7017637051;  // Replace with your numeric ID

// =======================================================
// DATABASE CONFIGURATION (MySQL)
// =======================================================
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'your_mysql_user');
define('DB_PASSWORD', 'your_mysql_password');
define('DB_NAME', 'your_database_name');

$db_config = [
    'host' => DB_HOST,
    'username' => DB_USERNAME,
    'password' => DB_PASSWORD,
    'database' => DB_NAME
];

// =======================================================
// OPTIONAL: Google Translate API Key
// =======================================================
$google_translate_api = '';  // Leave empty if not used

// =======================================================
// OPTIONAL: Proxy Configuration
// =======================================================
$proxy_config = [
    'server' => '',  // e.g., 'proxy.example.com:8080'
    'auth' => '',    // 'username:password'
    'type' => 'SOCKS5'
];

// =======================================================
// AUTHORIZED CHATS (user/group IDs allowed to use the bot)
// =======================================================
$authorized_chats = [
    $Mi_Id,  // Your ID is already authorized
    // -1001234567890,  // Example group ID
];

// =======================================================
// GENERAL CONFIGURATION
// =======================================================
define('typing', 'typing');

$log_config = [
    'enable_logs' => true,
    'log_file' => __DIR__ . '/logs/bot.log',
    'error_log' => __DIR__ . '/logs/error.log'
];

// =======================================================
// CONFIGURATION FUNCTIONS (DO NOT MODIFY)
// =======================================================
function getDbConfig() {
    return [
        'host' => DB_HOST,
        'username' => DB_USERNAME,
        'password' => DB_PASSWORD,
        'database' => DB_NAME
    ];
}

function getProxyConfig() {
    global $proxy_config;
    return $proxy_config;
}

function getGoogleTranslateApiKey() {
    global $google_translate_api;
    return $google_translate_api;
}

function isChatAuthorized($chat_id) {
    global $authorized_chats, $Mi_Id;
    return in_array($chat_id, $authorized_chats) || $chat_id == $Mi_Id;
}

function getBotToken() {
    global $botToken;
    return $botToken;
}

function getOwnerId() {
    global $Mi_Id;
    return $Mi_Id;
}
?>